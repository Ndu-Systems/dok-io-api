<?php

 function error($msg)
{
 return  $err["message"] = $msg;
}